#ifndef SNIRS_BENCHMARK_H
#define SNIRS_BENCHMARK_H

#include "scanner.h"
#include <stdint.h>

typedef struct {
    const char *name;
    const Scanner *scanner;
} BenchScanner;

/* TSV manifest: name, family, data path, expected-token path. Paths have no tabs. */
int benchmark_run(const BenchScanner *variants, size_t count, int argc, char **argv);

#endif
